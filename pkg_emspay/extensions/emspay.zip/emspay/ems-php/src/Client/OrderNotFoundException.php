<?php

namespace GingerPayments\Payment\Client;

final class OrderNotFoundException extends \RuntimeException
{
}
