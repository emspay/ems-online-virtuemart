<?php

namespace GingerPayments\Payment\Tests\Mock;

use GingerPayments\Payment\Common\IntegerBasedValueObject;

final class FakeIntegerBasedValueObject
{
    use IntegerBasedValueObject;
}
